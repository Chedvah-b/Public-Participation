import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-urban-planner',
  templateUrl: './urban-planner.component.html',
  styleUrls: ['./urban-planner.component.css']
})
export class UrbanPlannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
